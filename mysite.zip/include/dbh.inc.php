<?php
$dbServername = "localhost";
$dbUsername = "id5085405_root";
$dbPassword = "8642qQwW";
$dbName = "id5085405_loginsystem";
$conn = mysqli_connect($dbServername, $dbUsername , $dbPassword , $dbName);
?>