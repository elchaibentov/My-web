<!-- hitwebcounter Code START -->
<a href="http://www.hitwebcounter.com" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=6916517&style=0009&nbdigits=5&type=ip&initCount=0" title="web page hit counters codes Free" Alt="web page hit counters codes Free"   border="0" >
</a>                                        <br/>
                                        <!-- hitwebcounter.com --><a href="http://www.hitwebcounter.com" title="" 
                                        target="_blank" style="font-family: ; 
                                        font-size: px; color: #; text-decoration:  ;">                                   </>
                                        </a> 
<html> 
    <head>
        <title></title>
        <link rel="stylesheet" type="text/html" href="style.css">
    </head>
	 <body>
	 <header>
		<nav>
			<div class  ="main-wrapper">
				<ul> 
					<li><a href="../index.php">Home</a></li>
				</ul>
				<div class="nav-login">
					<form action="../login.inc.php" method="POST">
						<input type="text" name="uid" placeholder = "stageX+1"
						>
						<input type="password" name="pwd" placeholder = "password">
						<button type="submit" name="submit">next level</button>
					</form>
	 </header>
