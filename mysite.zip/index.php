  <!-- hitwebcounter Code START -->
<a href="http://www.hitwebcounter.com" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=6916517&style=0009&nbdigits=5&type=ip&initCount=0" title="web page hit counters codes Free" Alt="web page hit counters codes Free"   border="0" >
</a>                                        <br/>
                                        <!-- hitwebcounter.com --><a href="http://www.hitwebcounter.com" title="" 
                                        target="_blank" style="font-family: ; 
                                        font-size: px; color: #; text-decoration:  ;">  
<!------------------------------------------------------------------------------------------------------------------>
                                        </a> 
                            
<link rel="stylesheet" type="text/css" href="style.css">
<div id="lu">
    Elchai bentov </br>
    contact me: Elchaibentov1@gmail.com </br>
    tel: 0509144118
</div>
<section class="main-container">
	<div class="main-wrapper">
		<h2> Home </h2>
		  <h3>
		    <p>
		        This site consists several steps.<br/>
		        Each step has a password and user to move on to the next level.<br/>
		        Find the clues to find out the password.  <br/>
	            username for stageX=stage(x+1)--(for example: username for stage1=stage2)
	        </p>
	        <li><a href="stages/stage1.php">GO to stage1</a></li>
	        </h3>
	</div>
	</section>	
	<canvas id="c"></canvas>
<script src="letter.js"></script>

